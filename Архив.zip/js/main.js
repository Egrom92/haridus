

/*
DELETE CLASS START

TRUE -> add.class
FALSE -> remove.class

*/

function toggleWorkClass(addOrRemove, selector, className) {

    let el = document.querySelector(selector).classList;

    if (addOrRemove === true) {
        el.add(className);
    } else {
        el.remove(className);
    }

}
//DELETE CLASS END




//School name and info

    function openSchoolInfo(evt, schoolNum) {


            toggleWorkClass(false,'.school__wrap', 'js_schoolWrapClass');

            let schoolInfo, tabSchool;
            schoolInfo = document.getElementsByClassName("jsSchoolInfo");
            for (let j = 0; j < schoolInfo.length; j++) {
                schoolInfo[j].style.display = "none";
            }

            tabSchool = document.getElementsByClassName("jsTabSchool");
            for (let j = 0; j < tabSchool.length; j++) {
                tabSchool[j].className = tabSchool[j].className.replace(" jsTabSchoolActive", "");
            }
            document.getElementById(schoolNum).style.display = "flex";
            evt.currentTarget.className += " jsTabSchoolActive";
    }







    //School categories

    let accordionButton = document.getElementsByClassName("jsAccordion");

    for (let i = 0; i < accordionButton.length; i++) {
        accordionButton[i].addEventListener("click", function() {
            console.log(accordionButton)
            this.classList.toggle("jsAccordionActive");
            let panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            }
        });
    }





// SMOOTH SCROLLING ON ANCHORS START

    function throttle(func, wait, options) {
        let context, args, result;
        let timeout = null;
        let previous = 0;
        if (!options) options = {};
        let later = function() {
            previous = options.leading === false ? 0 : Date.now();
            timeout = null;
            result = func.apply(context, args);
            if (!timeout) context = args = null;
        };
        return function() {
            let now = Date.now();
            if (!previous && options.leading === false) previous = now;
            let remaining = wait - (now - previous);
            context = this;
            args = arguments;
            if (remaining <= 0 || remaining > wait) {
                if (timeout) {
                    clearTimeout(timeout);
                    timeout = null;
                }
                previous = now;
                result = func.apply(context, args);
                if (!timeout) context = args = null;
            } else if (!timeout && options.trailing !== false) {
                timeout = setTimeout(later, remaining);
            }
            return result;
        };
    }

    let scrollBodyClasss = document.querySelector('.js_body'); //Active head and footer


    // Добавялем throttle
    window.addEventListener('scroll', throttle(scrollFunctionFirst, 200));

    function scrollFunctionFirst() {
        function scrollFunctionInner(classFound, classAdd, px) {
            if (classFound) {
                if (document.body.scrollTop > px || document.documentElement.scrollTop > px) {
                    classFound.classList.add(classAdd);
                } else {
                    classFound.classList.remove(classAdd);
                }
            }
        }

        scrollFunctionInner(scrollBodyClasss, 'js_activeScroll', 25);
    }


    // Initial state
    var scrollPos = 200;
    // adding scroll event
    window.addEventListener('scroll', function(){
        if(window.innerWidth < 576 && document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            // detects new state and compares it with the new one
            if ((document.body.getBoundingClientRect()).top > scrollPos)
                document.querySelector('.js_body').classList.remove('js_scrollHideBlock');
            else
                document.querySelector('.js_body').classList.add('js_scrollHideBlock');
            // saves the new position for iteration.
            scrollPos = (document.body.getBoundingClientRect()).top;
        }
    });
// SMOOTH SCROLLING ON ANCHORS END



















